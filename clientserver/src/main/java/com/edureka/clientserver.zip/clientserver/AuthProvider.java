package com.edureka.clientserver;

public enum  AuthProvider {
    local,
    facebook,
    google,
    github
}