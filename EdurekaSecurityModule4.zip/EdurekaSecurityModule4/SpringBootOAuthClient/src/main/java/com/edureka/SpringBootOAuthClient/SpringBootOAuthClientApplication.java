package com.edureka.SpringBootOAuthClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOAuthClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOAuthClientApplication.class, args);
	}

}
