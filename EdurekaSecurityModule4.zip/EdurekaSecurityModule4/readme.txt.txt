Run Both the application.

Access Client Application: 
http://localhost:8082/welcome

User Username Password: dipika/dipika